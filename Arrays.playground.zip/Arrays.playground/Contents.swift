import UIKit

// Declaring an array
var ages = [21, 34, 20, 19, 43]


// If you want to declare an empty array:
var nums: [Int] = []


// To get the amount of elements in an array:
let amount = ages.count
print(amount)


// To get the last value in an array:
ages.last
print(ages.last as Any)


// To get the first value in an array:
ages.first
print(ages.first as Any)


// To get a specific index of an array:
ages[2] // 2 = index


// To append to an array:
ages.append(18)

print(ages)
